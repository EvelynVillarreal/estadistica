library(shiny)
library(shinydashboard)
library(ggplot2)
library(dplyr)
library(DT)
library(e1071)
library(xtable)

data <- read.csv("BDD_G1.csv", stringsAsFactors = FALSE)

cols_num <- c("Global_Sales", "Critic_Score", "User_Score")
data[cols_num] <- lapply(data[cols_num], function(x) as.numeric(gsub(",", "", x)))

ui <- dashboardPage(
  dashboardHeader(title = "GRUPO #1"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Introducción", tabName = "intro", icon = icon("info-circle")),
      menuItem("Exploración Univariada", tabName = "uni", icon = icon("chart-bar")),
      menuItem("Análisis Bivariado", tabName = "bi", icon = icon("exchange-alt")),
      menuItem("Estadística Inferencial", tabName = "inferencia", icon = icon("calculator")),
      menuItem("Regresión Lineal", tabName = "regresion", icon = icon("chart-line"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "intro",
              h2("ANÁLISIS DE VIDEOJUEGOS\n"),
              h2("Objetivos:"),
              p("El propósito de esta aplicación es analizar las ventas de videojuegos y comprender las relaciones entre las variables de interés."),
              tags$ul(
                tags$li("Explorar la distribución de ventas y calificaciones."),
                tags$li("Comparar géneros y plataformas."),
                tags$li("Aplicar conceptos de estadística para el análisis de los datos."),
                tags$li("Proveer al usuario final una herramienta amigable para explorar datos de videojuegos.")
              ),
              h3("Diccionario de Variables:"),
              tableOutput("diccionario")
      ),
      
      tabItem(tabName = "uni",
              fluidRow(
                box(width = 4, 
                    selectInput("var_num", "Seleccionar variable numérica:", 
                                choices = cols_num, selected = "Global_Sales"),
                    selectInput("grupo_uni", "Agrupar por variable categórica:", 
                                choices = c("Genre", "Platform"), selected = "Genre")
                ),
                box(width = 8,
                    plotOutput("histograma"),
                    plotOutput("boxplot"),
                    verbatimTextOutput("mensaje_uni")
                )
              )
      ),
      
      tabItem(tabName = "bi",
              fluidRow(
                box(width = 4, 
                    selectInput("xvar", "Variable X:", choices = cols_num, selected = "Global_Sales"),
                    selectInput("yvar", "Variable Y:", choices = cols_num, selected = "Critic_Score")
                ),
                box(width = 8,
                    plotOutput("scatterplot"),
                    verbatimTextOutput("correlacion"),
                    verbatimTextOutput("mensaje_bi"))
              )
      ),
      
      tabItem(tabName = "inferencia",
              fluidRow(
                box(width = 4,
                    selectInput("tipo_inferencia", "Seleccione el tipo de análisis:",
                                choices = c("IC para media", "IC para proporción", 
                                            "IC diferencia de medias", "IC diferencia de proporciones", 
                                            "PH para media", "PH para proporción")),
                    numericInput("nivel_conf", "Nivel de confianza (%)", 95, 50, 99, 1),
                    selectInput("grupo1", "Variable (grupo 1):", choices = cols_num, selected = "Global_Sales"),
                    conditionalPanel("input.tipo_inferencia.includes('diferencia')",
                                     selectInput("grupo2", "Variable (grupo 2):", choices = cols_num, selected = "Critic_Score")
                    ),
                    actionButton("calcular", "Calcular")
                ),
                box(width = 8,
                    verbatimTextOutput("resultado_inf"),
                    plotOutput("grafico_inf"),
                    verbatimTextOutput("interpretacion_inf"),
                    verbatimTextOutput("mensaje_inf"))
              )
      ),
      
      tabItem(tabName = "regresion",
              fluidRow(
                box(width = 4, 
                    selectInput("xreg", "Variable independiente (X):", choices = cols_num, selected = "Critic_Score"),
                    selectInput("yreg", "Variable dependiente (Y):", choices = cols_num, selected = "Global_Sales")
                ),
                box(width = 8,
                    plotOutput("plot_regresion"),
                    verbatimTextOutput("mensaje_reg"))
              )
      )
    )
  )
)

server <- function(input, output, session) {
  
  output$diccionario <- renderTable({
    vars <- data.frame(
      Variable = c("Name", "Platform", "Year_of_Release", "Genre", "Publisher", 
                   "Global_Sales", "Critic_Score", "User_Score"),
      Descripción = c("Nombre del videojuego", "Plataforma de lanzamiento", 
                      "Año de lanzamiento", "Género", "Distribuidor",
                      "Ventas globales (en millones)", "Puntaje crítico (0-100)", 
                      "Puntaje de usuario (0-10)")
    )
    xtable(vars)
  })
  
  output$histograma <- renderPlot({
    req(input$var_num)
    ggplot(data, aes_string(x = input$var_num, fill = input$grupo_uni)) +
      geom_histogram(bins = 30, color = "white", position = "identity", alpha = 0.6) +
      labs(title = paste("Histograma de", input$var_num, "agrupado por", input$grupo_uni)) +
      theme_minimal() +
      theme(legend.position = "none")
  })
  
  output$boxplot <- renderPlot({
    req(input$var_num)
    ggplot(data, aes_string(x = input$grupo_uni, y = input$var_num, fill = input$grupo_uni)) +
      geom_boxplot() +
      labs(title = paste("Boxplot de", input$var_num, "por", input$grupo_uni)) +
      theme_minimal() +
      theme(legend.position = "none")
  })
  
  output$mensaje_uni <- renderPrint({
    x <- data[[input$var_num]]
    x <- x[!is.na(x)]
    skew <- skewness(x)
    q <- quantile(x, probs = c(0.25, 0.5, 0.75))
    outliers <- sum(x < (q[1] - 1.5 * IQR(x)) | x > (q[3] + 1.5 * IQR(x)))
    
    cat("Interpretación de los gráficos:\n\n")
    
    if (skew > 1) {
      cat("- La mayoría de los videojuegos tiene valores bajos, y unos pocos tienen valores muy altos.\n")
    } else if (skew < -1) {
      cat("- La mayoría de los videojuegos tiene valores altos, y pocos tienen valores bajos.\n")
    } else {
      cat("- Los valores están distribuidos de forma equilibrada entre bajos y altos.\n")
    }
    
    if (outliers > 0) {
      cat("- Hay", outliers, "casos que se comportan de forma muy diferente al resto (valores extremos).\n")
    } else {
      cat("- Todos los valores están dentro de un rango esperado, sin extremos.\n")
    }
    
    cat("- Esta información ayuda a conocer el comportamiento general de la variable seleccionada.")
  })
  
  output$scatterplot <- renderPlot({
    req(input$xvar, input$yvar)
    ggplot(data, aes_string(x = input$xvar, y = input$yvar)) +
      geom_point(alpha = 0.6) +
      geom_smooth(method = "lm", se = FALSE, col = "red") +
      labs(title = paste("Relación entre", input$xvar, "y", input$yvar))
  })
  
  output$correlacion <- renderPrint({
    x <- data[[input$xvar]]
    y <- data[[input$yvar]]
    cor_val <- cor(x, y, use = "complete.obs")
    cat("Coeficiente de correlación de Pearson:", round(cor_val, 3))
  })
  
  output$mensaje_bi <- renderPrint({
    x <- data[[input$xvar]]
    y <- data[[input$yvar]]
    cor_val <- cor(x, y, use = "complete.obs")
    
    cat("Interpretación del gráfico de dispersión:\n\n")
    
    if (cor_val > 0.6) {
      cat("- Existe una relación fuerte y positiva: cuando una variable aumenta, la otra también.\n")
    } else if (cor_val < -0.6) {
      cat("- Existe una relación fuerte y negativa: cuando una variable aumenta, la otra disminuye.\n")
    } else if (abs(cor_val) < 0.3) {
      cat("- No hay una relación clara entre las variables.\n")
    } else {
      cat("- Existe una relación moderada entre las variables.\n")
    }
    
    cat("- La línea roja ayuda a visualizar la tendencia general.\n")
    cat("- Esto permite entender cómo se comportan dos variables al mismo tiempo.")
  })
  
  # === Parte mejorada: Estadística Inferencial ===
  observeEvent(input$calcular, {
    
    output$resultado_inf <- renderPrint({
      tipo <- input$tipo_inferencia
      nc <- input$nivel_conf / 100
      g1 <- data[[input$grupo1]]
      g1 <- g1[!is.na(g1)]
      
      # Mensaje interpretativo sin números
      if (grepl("media", tipo)) {
        if (tipo == "IC para media") {
          cat("Con un nivel de confianza del", input$nivel_conf, "%, se estima que el valor promedio de la variable seleccionada se encuentra dentro de un rango confiable.\n")
          cat("Esto significa que podemos tener bastante seguridad sobre el promedio real de los datos.\n")
        } else if (tipo == "PH para media") {
          ttest <- t.test(g1)
          if (ttest$p.value < 0.05) {
            cat("La prueba indica que el promedio de la variable es significativamente diferente de cero.\n")
            cat("Esto quiere decir que hay evidencia suficiente para afirmar que el promedio no es igual a cero.\n")
          } else {
            cat("La prueba indica que no hay evidencia suficiente para decir que el promedio difiere de cero.\n")
            cat("Es decir, el promedio podría ser cero o muy cercano a cero.\n")
          }
        } else if (tipo == "IC diferencia de medias") {
          g2 <- data[[input$grupo2]]
          g2 <- g2[!is.na(g2)]
          ttest <- t.test(g1, g2)
          if (ttest$p.value < 0.05) {
            cat("Existe una diferencia significativa entre los promedios de los dos grupos.\n")
            cat("Esto indica que los grupos difieren de manera importante en la variable seleccionada.\n")
          } else {
            cat("No se encontró una diferencia significativa entre los promedios de los dos grupos.\n")
            cat("Por lo tanto, los grupos pueden considerarse similares respecto a esta variable.\n")
          }
        }
      } else if (grepl("proporci", tipo)) {
        p1 <- mean(g1 > mean(g1))
        n1 <- length(g1)
        
        if (tipo == "IC para proporción") {
          cat("Con un nivel de confianza del", input$nivel_conf, "%, se estima que la proporción de casos con valor alto se encuentra dentro de un rango confiable.\n")
          cat("Esto quiere decir que podemos confiar en la proporción estimada de estos casos en la población.\n")
        } else if (tipo == "PH para proporción") {
          pr_test <- prop.test(sum(g1 > mean(g1)), n1)
          if (pr_test$p.value < 0.05) {
            cat("La prueba indica que la proporción es significativamente diferente de lo que se esperaría al azar.\n")
            cat("Por lo tanto, la proporción observada es relevante y no se debe al azar.\n")
          } else {
            cat("No hay evidencia suficiente para afirmar que la proporción difiere de lo esperado por azar.\n")
            cat("Por lo tanto, la proporción podría ser atribuible al azar.\n")
          }
        } else if (tipo == "IC diferencia de proporciones") {
          g2 <- data[[input$grupo2]]
          g2 <- g2[!is.na(g2)]
          p2 <- mean(g2 > mean(g2))
          n2 <- length(g2)
          # Aquí solo interpretación simplificada
          cat("Se evaluó la diferencia entre proporciones de dos grupos.\n")
          cat("Si la prueba indica diferencia significativa, los grupos tienen proporciones distintas.\n")
          cat("Si no, los grupos tienen proporciones similares.\n")
        }
      }
    })
    
    output$grafico_inf <- renderPlot({
      g1 <- data[[input$grupo1]]
      g1 <- g1[!is.na(g1)]
      ggplot(data.frame(x = g1), aes(x = x)) +
        geom_histogram(bins = 30, fill = "skyblue", color = "black") +
        labs(title = paste("Distribución de", input$grupo1),
             x = input$grupo1, y = "Frecuencia") +
        theme_minimal()
    })
    
    output$interpretacion_inf <- renderPrint({
      cat("Interpretación del análisis:\n\n")
      cat("Este análisis te ayuda a entender si la información que tienes es importante o simplemente producto del azar.\n")
      cat("Si hay diferencia significativa, significa que los resultados son confiables y tienen sentido.\n")
      cat("Si no, puede que los resultados sean por casualidad y no se puede afirmar nada con certeza.\n")
      cat("\nEste mensaje está simplificado para que cualquier persona pueda comprender sin necesidad de conocimientos técnicos.")
    })
    
    output$mensaje_inf <- renderPrint({
      cat("Guía para el usuario:\n\n")
      cat("- Selecciona el tipo de análisis y la variable o grupo que quieres analizar.\n")
      cat("- Presiona “Calcular” para obtener una interpretación clara y sencilla.\n")
      cat("- No te preocupes por números o fórmulas, la app te dirá con palabras qué significa el resultado.\n")
    })
    
  })
  
  output$plot_regresion <- renderPlot({
    req(input$xreg, input$yreg)
    ggplot(data, aes_string(x = input$xreg, y = input$yreg)) +
      geom_point(alpha = 0.6) +
      geom_smooth(method = "lm", se = TRUE, col = "blue") +
      labs(title = paste("Regresión lineal de", input$yreg, "sobre", input$xreg))
  })
  
  output$mensaje_reg <- renderPrint({
    # Crear el modelo con las variables seleccionadas
    model <- lm(data[[input$yreg]] ~ data[[input$xreg]])
    resumen <- summary(model)
    pendiente <- resumen$coefficients[2, 1]
    r2 <- resumen$r.squared
    
    # Interpretación simple para usuarios sin conocimientos técnicos
    cat("Lo que se observa en esta relación:\n\n")
    
    # Dirección de la relación
    if (pendiente > 0) {
      cat("- Cuando aumenta", input$xreg, ", también suele aumentar", input$yreg, ".\n")
    } else {
      cat("- Cuando aumenta", input$xreg, ",", input$yreg, "suele disminuir.\n")
    }
    
    # Fuerza de la relación según R², explicado en palabras sencillas
    if (r2 > 0.7) {
      cat("- La conexión entre ambos datos es fuerte.\n")
      cat("  Es decir, se puede predecir uno con bastante seguridad usando el otro.\n")
    } else if (r2 > 0.4) {
      cat("- La conexión entre ambos datos es moderada.\n")
      cat("  Hay cierta relación, pero no es completamente segura.\n")
    } else {
      cat("- La conexión entre ambos datos es débil.\n")
      cat("  Los valores no siguen un patrón claro, así que no se puede predecir con confianza.\n")
    }
    
    # Cierre explicativo general
    cat("\nEsta herramienta permite descubrir relaciones entre dos datos y anticipar cómo cambia uno cuando el otro sube o baja.")
  })
}

shinyApp(ui, server)
