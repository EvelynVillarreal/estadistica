# app.R

library(shiny)
library(shinydashboard)
library(ggplot2)
library(dplyr)
library(DT)
library(e1071)
library(xtable)

# ------------------ CARGAR Y DEPURAR DATOS ------------------
data <- read.csv("BDD_G1.csv", stringsAsFactors = FALSE)

# Reemplazo y limpieza básica de columnas numéricas
cols_num <- c("Global_Sales", "Critic_Score", "User_Score")
data[cols_num] <- lapply(data[cols_num], function(x) as.numeric(gsub(",", "", x)))

# ------------------ UI ------------------
ui <- dashboardPage(
  dashboardHeader(title = "GRUPO #1"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Introducción", tabName = "intro", icon = icon("info-circle")),
      menuItem("Exploración Univariada", tabName = "uni", icon = icon("chart-bar")),
      menuItem("Análisis Bivariado", tabName = "bi", icon = icon("exchange-alt")),
      menuItem("Estadística Inferencial", tabName = "inferencia", icon = icon("calculator"))
    )
  ),
  dashboardBody(
    tabItems(
      # INTRODUCCIÓN
      tabItem(tabName = "intro",
              h2("ANÁLISIS DE VIDEOJUEGOS\n"),
              h2("Objetivos:"),
              p("El propósito de esta aplicación es analizar las ventas de videojuegos y comprender las relaciones entre las variables de interés."),
              tags$ul(
                tags$li("Explorar la distribución de ventas y calificaciones."),
                tags$li("Comparar géneros y plataformas."),
                tags$li("Aplicar conceptos de estadística descriptiva e inferencial."),
                tags$li("Proveer al usuario final una herramienta amigable para explorar datos de videojuegos.")
              ),
              h3("Diccionario de Variables:"),
              tableOutput("diccionario")
      ),
      
      # UNIVARIADO
      tabItem(tabName = "uni",
              fluidRow(
                box(width = 4, 
                    selectInput("var_num", "Seleccionar variable numérica:", 
                                choices = cols_num, selected = "Global_Sales"),
                    selectInput("grupo_uni", "Agrupar por variable categórica:", 
                                choices = c("Genre", "Platform"), selected = "Genre")
                ),
                box(width = 8,
                    plotOutput("histograma"),
                    plotOutput("boxplot"),
                    verbatimTextOutput("medidas_desc"),
                    verbatimTextOutput("mensaje_uni")
                )
              )
      ),
      
      # BIVARIADO
      tabItem(tabName = "bi",
              fluidRow(
                box(width = 4, 
                    selectInput("xvar", "Variable X:", choices = cols_num, selected = "Global_Sales"),
                    selectInput("yvar", "Variable Y:", choices = cols_num, selected = "Critic_Score")
                ),
                box(width = 8,
                    plotOutput("scatterplot"),
                    verbatimTextOutput("correlacion"),
                    verbatimTextOutput("mensaje_bi"))
              )
      ),
      
      # INFERENCIAL
      tabItem(tabName = "inferencia",
              fluidRow(
                box(width = 4,
                    selectInput("tipo_inferencia", "Seleccione el tipo de análisis:",
                                choices = c("IC para media", "IC para proporción", 
                                            "IC diferencia de medias", "IC diferencia de proporciones", 
                                            "PH para media", "PH para proporción")),
                    numericInput("nivel_conf", "Nivel de confianza (%)", 95, 50, 99, 1),
                    selectInput("grupo1", "Variable (grupo 1):", choices = cols_num, selected = "Global_Sales"),
                    conditionalPanel("input.tipo_inferencia.includes('diferencia')",
                                     selectInput("grupo2", "Variable (grupo 2):", choices = cols_num, selected = "Critic_Score")
                    ),
                    actionButton("calcular", "Calcular")
                ),
                box(width = 8,
                    verbatimTextOutput("resultado_inf"),
                    verbatimTextOutput("mensaje_inf"))
              )
      )
    )
  )
)

# ------------------ SERVER ------------------
server <- function(input, output, session) {
  
  # DICCIONARIO DE VARIABLES
  output$diccionario <- renderTable({
    vars <- data.frame(
      Variable = c("Name", "Platform", "Year_of_Release", "Genre", "Publisher", 
                   "Global_Sales", "Critic_Score", "User_Score"),
      Descripción = c("Nombre del videojuego", "Plataforma de lanzamiento", 
                      "Año de lanzamiento", "Género", "Distribuidor",
                      "Ventas globales (en millones)", "Puntaje crítico (0-100)", 
                      "Puntaje de usuario (0-10)")
    )
    xtable(vars)
  })
  
  # ANÁLISIS UNIVARIADO
  output$histograma <- renderPlot({
    req(input$var_num)
    ggplot(data, aes_string(x = input$var_num, fill = input$grupo_uni)) +
      geom_histogram(bins = 30, color = "white", position = "identity", alpha = 0.6) +
      labs(title = paste("Histograma de", input$var_num, "agrupado por", input$grupo_uni)) +
      theme_minimal() +
      theme(legend.position = "none")
  })
  
  output$boxplot <- renderPlot({
    req(input$var_num)
    ggplot(data, aes_string(x = input$grupo_uni, y = input$var_num, fill = input$grupo_uni)) +
      geom_boxplot() +
      labs(title = paste("Boxplot de", input$var_num, "por", input$grupo_uni)) +
      theme_minimal() +
      theme(legend.position = "none")
  })
  
  output$medidas_desc <- renderPrint({
    x <- data[[input$var_num]]
    x <- x[!is.na(x)]
    cat("Media:", mean(x), "\n")
    cat("Mediana:", median(x), "\n")
    cat("Desviación estándar:", sd(x), "\n")
    cat("Cuartiles:\n"); print(quantile(x, probs = c(0.25, 0.5, 0.75)))
  })
  
  output$mensaje_uni <- renderPrint({
    cat("Interpretación gráfica de la variable seleccionada:\n")
    cat("El histograma muestra la distribución de los datos.\nEl boxplot indica la dispersión y presencia de valores atípicos.\nLas medidas resumen permiten comprender el comportamiento general de la variable.")
  })
  
  # ANÁLISIS BIVARIADO
  output$scatterplot <- renderPlot({
    req(input$xvar, input$yvar)
    ggplot(data, aes_string(x = input$xvar, y = input$yvar)) +
      geom_point(alpha = 0.6) +
      geom_smooth(method = "lm", se = FALSE, col = "red") +
      labs(title = paste("Relación entre", input$xvar, "y", input$yvar))
  })
  
  output$correlacion <- renderPrint({
    x <- data[[input$xvar]]
    y <- data[[input$yvar]]
    cor_val <- cor(x, y, use = "complete.obs")
    cat("Coeficiente de correlación de Pearson:", round(cor_val, 3))
  })
  
  output$mensaje_bi <- renderPrint({
    cat("Interpretación del análisis bivariado:\n")
    cat("El gráfico de dispersión permite visualizar si existe una relación lineal entre las variables seleccionadas.\nLa línea de tendencia y el coeficiente de correlación ayudan a confirmar si la relación es positiva, negativa o nula.")
  })
  
  # ESTADÍSTICA INFERENCIAL
  observeEvent(input$calcular, {
    output$resultado_inf <- renderPrint({
      tipo <- input$tipo_inferencia
      nc <- input$nivel_conf / 100
      g1 <- data[[input$grupo1]]
      g1 <- g1[!is.na(g1)]
      
      if (grepl("media", tipo)) {
        if (tipo == "IC para media") {
          error <- qnorm(1 - (1 - nc) / 2) * sd(g1)/sqrt(length(g1))
          cat("Intervalo de Confianza para la media:", mean(g1) - error, ",", mean(g1) + error)
        } else if (tipo == "PH para media") {
          ttest <- t.test(g1)
          cat("Prueba de Hipótesis para la media:\n")
          cat("Estadístico t:", round(ttest$statistic, 3), "\n")
          cat("Valor-p:", round(ttest$p.value, 5), "\n")
          if (ttest$p.value < 0.05) {
            cat("Conclusión: Se rechaza la hipótesis nula al 5% de significancia.")
          } else {
            cat("Conclusión: No se puede rechazar la hipótesis nula al 5% de significancia.")
          }
        } else if (tipo == "IC diferencia de medias") {
          g2 <- data[[input$grupo2]]
          g2 <- g2[!is.na(g2)]
          ttest <- t.test(g1, g2)
          cat("Intervalo de Confianza para la diferencia de medias:", round(ttest$conf.int[1], 3), ",", round(ttest$conf.int[2], 3))
        }
      } else if (grepl("proporci", tipo)) {
        p1 <- mean(g1 > mean(g1))
        n1 <- length(g1)
        
        if (tipo == "IC para proporción") {
          error <- qnorm(1 - (1 - nc) / 2) * sqrt(p1*(1 - p1)/n1)
          cat("Intervalo de Confianza para proporción:", round(p1 - error, 3), ",", round(p1 + error, 3))
        } else if (tipo == "PH para proporción") {
          pr_test <- prop.test(sum(g1 > mean(g1)), n1)
          cat("Prueba de Hipótesis para una proporción:\n")
          cat("Estadístico Chi-cuadrado:", round(pr_test$statistic, 3), "\n")
          cat("Valor-p:", round(pr_test$p.value, 5), "\n")
          if (pr_test$p.value < 0.05) {
            cat("Conclusión: Se rechaza la hipótesis nula al 5% de significancia.")
          } else {
            cat("Conclusión: No se puede rechazar la hipótesis nula al 5% de significancia.")
          }
        } else if (tipo == "IC diferencia de proporciones") {
          g2 <- data[[input$grupo2]]
          g2 <- g2[!is.na(g2)]
          p2 <- mean(g2 > mean(g2))
          n2 <- length(g2)
          diff <- p1 - p2
          se <- sqrt(p1*(1 - p1)/n1 + p2*(1 - p2)/n2)
          error <- qnorm(1 - (1 - nc) / 2) * se
          cat("IC diferencia de proporciones:", round(diff - error, 3), ",", round(diff + error, 3))
        }
      }
    })
    
    output$mensaje_inf <- renderPrint({
      cat("Interpretación del análisis inferencial:\n")
      cat("Esta sección permite estimar parámetros poblacionales y contrastar hipótesis estadísticas mediante intervalos de confianza y pruebas.\nEl usuario puede seleccionar variables y el tipo de análisis para tomar decisiones basadas en evidencia.")
    })
  })
}

# ------------------ SHINY APP ------------------
shinyApp(ui, server)
